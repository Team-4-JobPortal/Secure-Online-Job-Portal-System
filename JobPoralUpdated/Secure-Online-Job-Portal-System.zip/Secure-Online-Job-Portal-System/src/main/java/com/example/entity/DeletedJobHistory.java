package com.example.entity;

import javax.persistence.*;
import java.sql.Date;
import java.time.LocalDateTime;

@Entity
@Table(name = "deleted_jobs_history")
public class DeletedJobHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "deleted_job_id")
    private int deletedJobId;

    // Original job details
    @Column(name = "original_job_id")
    private int originalJobId;

    @Column(name = "title")
    private String title;

    @Column(name = "description", length = 1000)
    private String description;

    @Column(name = "location")
    private String location;

    @Column(name = "min_salary")
    private int minSalary;

    @Column(name = "max_salary")
    private int maxSalary;

    @Column(name = "posting_date")
    private LocalDateTime originalCreatedAt;

    @Column(name = "application_deadline")
    private Date deadline;

    // Deletion tracking
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    @Column(name = "deleted_by")
    private String deletedBy;

    // Employer information
    @ManyToOne
    @JoinColumn(name = "employer_id")
    private User employer;

    // Constructors
    public DeletedJobHistory() {}

    // Constructor to create from existing Job
    public DeletedJobHistory(Job job, String deletedBy) {
        this.originalJobId = job.getJob_id();
        this.title = job.getTitle();
        this.description = job.getDescription();
        this.location = job.getLocation();
        this.minSalary = job.getMin_salary();
        this.maxSalary = job.getMax_salary();
        this.originalCreatedAt = job.getCreatedAt();
        this.deadline = job.getDeadline();
        this.employer = job.getUser();
        this.deletedAt = LocalDateTime.now();
        this.deletedBy = deletedBy;
    }

    // Getters and Setters
    public int getDeletedJobId() {
        return deletedJobId;
    }

    public void setDeletedJobId(int deletedJobId) {
        this.deletedJobId = deletedJobId;
    }

    public int getOriginalJobId() {
        return originalJobId;
    }

    public void setOriginalJobId(int originalJobId) {
        this.originalJobId = originalJobId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getMinSalary() {
        return minSalary;
    }

    public void setMinSalary(int minSalary) {
        this.minSalary = minSalary;
    }

    public int getMaxSalary() {
        return maxSalary;
    }

    public void setMaxSalary(int maxSalary) {
        this.maxSalary = maxSalary;
    }

    public LocalDateTime getOriginalCreatedAt() {
        return originalCreatedAt;
    }

    public void setOriginalCreatedAt(LocalDateTime originalCreatedAt) {
        this.originalCreatedAt = originalCreatedAt;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public LocalDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(LocalDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public User getEmployer() {
        return employer;
    }

    public void setEmployer(User employer) {
        this.employer = employer;
    }
}
