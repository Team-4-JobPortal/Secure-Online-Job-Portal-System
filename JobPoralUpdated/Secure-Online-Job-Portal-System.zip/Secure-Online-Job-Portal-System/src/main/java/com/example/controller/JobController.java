package com.example.controller;

import com.example.entity.Application;
import com.example.entity.DeletedJobHistory;
import com.example.entity.Job;
import com.example.entity.User;
import com.example.service.ApplicationService;
import com.example.service.JobService;
import com.example.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

@RestController
@RequestMapping("/jobs")
public class JobController {

    @Autowired
    private JobService jobService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private ApplicationService applicationService;

    @PostMapping("/postJob")
    @ResponseBody
    public ResponseEntity<?> createJob(@Valid @RequestBody Job job,
                                       Authentication authentication) {
        String email = authentication.getName();
        User dbUser = userService.findByemail(email);
        if (dbUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("User not found!");
        }

        // Check role
        if (!"employer".equalsIgnoreCase(dbUser.getRole())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Only Employer can post jobs!");
        }
        
        job.setUser(dbUser);
        job.setCreatedAt(LocalDateTime.now());
        // save job
        jobService.createJob(job);
        System.out.println("Job posted successfully");
        return ResponseEntity.ok("Job posted successfully");
    }

    // Employer: Update Job
    @PutMapping("/{id}")
    public String updateJob(@PathVariable int id, @RequestBody Job updatedJob) {
        Job existingJob = jobService.getJobById(id);
        if (existingJob == null) {
            return "Job not found!";
        }
        updatedJob.setJob_id(id); // keep the same ID
        jobService.updateJob(updatedJob);
        return "Job updated successfully!";
    }

    
    
    
    
    
    
    
    
    
    // Employer: Delete Job with History 
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteJob(@PathVariable int id, Authentication authentication) {
        String email = authentication.getName();
        boolean deleted = jobService.deleteJobWithHistory(id, email);
        
        if (deleted) {
            return ResponseEntity.ok(Collections.singletonMap("message", "Job deleted and moved to history successfully!"));
        }
        return ResponseEntity.notFound().build();
    }

    // Get deleted jobs history for current employer
    @GetMapping("/deleted/history")
    public ResponseEntity<List<DeletedJobHistory>> getDeletedHistory(Authentication authentication) {
        String email = authentication.getName();
        User user = userService.findByemail(email);
        
        if (user == null) {
            return ResponseEntity.notFound().build();
        }
        
        List<DeletedJobHistory> deletedJobs = jobService.getDeletedJobsByEmployer(user.getUser_id());
        return ResponseEntity.ok(deletedJobs);
    }

   
    
    
    
    
    
    
    // Candidate: View All Jobs
    @GetMapping("/list")
    public List<Job> getAllJobs() {
        return jobService.getAllJobs();
    }

    // Candidate: Search Jobs
    @GetMapping("/search")
    public List<Job> searchJobs(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String minSalary,
            @RequestParam(required = false) String maxSalary) {
  			
        // fixing the default value if the user send data 
        // input is string is empty then initializing with zero
        int min = (minSalary == null || minSalary.isEmpty()) ? 0 : Integer.parseInt(minSalary);
        int max = (maxSalary == null || maxSalary.isEmpty()) ? 0 : Integer.parseInt(maxSalary);
        		
        return jobService.searchJobs(keyword, location, min, max);
    }

    // Common: Get Job by ID
    @GetMapping("/{id}")
    public Job getJobById(@PathVariable int id) {
        return jobService.getJobById(id);
    }
    
    @GetMapping("/currentLoginEmployerJobPosted/list")
    public List<Job> getMyJobs(Authentication authentication) {
        String email = authentication.getName(); // logged-in employer's email
        return jobService.getJobsByEmployer(email);
    }
    
    @PostMapping("/{jobId}/apply")
    public ResponseEntity<?> applyForJob(
            @PathVariable int jobId,
            @RequestBody Application request,
            Authentication authentication) {

        String email = authentication.getName();
        User dbUser = userService.findByemail(email);

        if (dbUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("User not found!");
        }

        // Only candidates can apply
        if (!"candidate".equalsIgnoreCase(dbUser.getRole())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Only Candidates can apply for jobs!");
        }

        Job job = jobService.getJobById(jobId);
        if (job == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Job not found!");
        }

        // CHECK IF USER HAS ALREADY APPLIED TO THIS JOB
        boolean hasAlreadyApplied = applicationService.hasUserAppliedToJob(dbUser.getUser_id(), jobId);
        if (hasAlreadyApplied) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("You have already applied to this job!");
        }

        // Validate cover letter
        if (request.getCoverLetter() == null || request.getCoverLetter().trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Cover letter is required!");
        }

        Application application = new Application();
        application.setJob(job);
        application.setUser(dbUser);
        application.setCoverLetter(request.getCoverLetter().trim());
        application.setStatus("Pending"); // default status

        try {
            applicationService.saveApp(application);
            System.out.println("Application saved successfully for Job ID: " + jobId + ", User ID: " + dbUser.getUser_id());
            return ResponseEntity.ok("Application submitted successfully with status Pending!");
        } catch (Exception e) {
            System.err.println("Error saving application: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to submit application. Please try again.");
        }
    }
}
