package com.example.dao;

import com.example.entity.DeletedJobHistory;
import com.example.entity.Job;
import java.util.List;
import java.util.Optional;

public interface JobDao {
    void save(Job job);
    Job get(int id);
    List<Job> list();
    void update(Job job);
    void delete(int id);
    List<Job> searchJobs(String keyword, String location, Integer minSalary, Integer maxSalary);
    List<Job> findByEmployerEmail(String email);
    List<Job> findByEmployerUserid(int empId);
    Optional<Job> findById(int id);
    
    // DeletedJobHistory methods in same DAO
    void saveDeletedJob(DeletedJobHistory deletedJob);
    List<DeletedJobHistory> findDeletedJobsByEmployerId(int employerId);
    List<DeletedJobHistory> findAllDeletedJobs();
    long countDeletedJobsByEmployerId(int employerId);

}
