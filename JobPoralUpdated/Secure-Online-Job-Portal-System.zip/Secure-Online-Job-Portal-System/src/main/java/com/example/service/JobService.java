package com.example.service;

import com.example.entity.DeletedJobHistory;
import com.example.entity.Job;
import java.util.List;

public interface JobService {
    void createJob(Job job);
    Job getJobById(int id);
    List<Job> getAllJobs();
    void updateJob(Job job);
    void deleteJob(int id);
    List<Job> searchJobs(String keyword, String location, Integer minSalary, Integer maxSalary);
    List<Job> getJobsByEmployer(String email);
    List<Job> findJobsByEmployer(int user_id);
    
   
    boolean deleteJobWithHistory(int jobId, String deletedBy);
    List<DeletedJobHistory> getDeletedJobsByEmployer(int employerId);
    List<DeletedJobHistory> getAllDeletedJobs();
    long getDeletedJobsCount(int employerId);
 
}
